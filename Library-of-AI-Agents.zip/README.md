# Library of AI Agents

A collection of powerful AI-powered agents for video processing, content generation, and more. These agents are designed to automate common tasks and provide high-quality results with minimal setup.

## 🤖 Available Agents

### 1. [ShortVid Agent](./shortvid_agent/)
Add beautiful subtitles to videos with OpenAI's Whisper transcription, or generate voiceovers with ElevenLabs.

**Key Features:**
- Transcribe video audio using OpenAI's Whisper
- Add customizable stylish subtitles
- Generate high-quality voiceovers with ElevenLabs
- Multiple subtitle style presets
- Process entire directories of videos in batch

[Learn more about ShortVid Agent →](./shortvid_agent/)

### 2. [Clips Agent](./clips_agent/)
Create high-quality, engaging clips from longer videos. Perfect for content creators and marketers.

**Key Features:**
- Extract the most interesting segments from long videos
- Process YouTube videos with automatic downloading
- Customizable clip duration
- Track analytics on generated clips
- Organize output in a clean directory structure

[Learn more about Clips Agent →](./clips_agent/)

## 📦 Installation

Each agent has its own dependencies and installation instructions. Please refer to the individual agent directories for specific setup guides.

General requirements:
- Python 3.8+
- FFmpeg
- Various Python packages (see individual agent README files)

## 🚀 Getting Started

1. Clone this repository:
```bash
git clone https://github.com/Kawzmp3/Library-of-AI-Agents.git
cd Library-of-AI-Agents
```

2. Navigate to the agent directory of your choice:
```bash
cd shortvid_agent
# or
cd clips_agent
```

3. Follow the agent-specific README instructions for setup and usage.

## 🔧 Common Usage

### ShortVid Agent
```bash
python shortvid_agent.py --all --style modern  # Process all videos with modern subtitle style
```

### Clips Agent
```bash
python clips_agent.py --url "https://www.youtube.com/watch?v=VIDEO_ID"  # Create clips from YouTube video
```

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

---

## Agent Directory Structure

```
Library-of-AI-Agents/
├── shortvid_agent/
│   ├── shortvid_agent.py
│   ├── README.md
│   └── data/
│       ├── audio/
│       ├── raw_videos/
│       ├── final_videos/
│       └── text_input/
│           └── input.txt
│
├── clips_agent/
│   ├── clips_agent.py
│   ├── README.md
│   └── data/
│       ├── videos/
│       ├── clips/
│       └── transcripts/
│
└── README.md
``` 